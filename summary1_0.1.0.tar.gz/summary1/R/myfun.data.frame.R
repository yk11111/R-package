#' Title
#'
#' @param object An object which type is data.frame
#' @param maxsum integer,limiting how many levels should be shown.
#' @param digits integer,used for number formatting
#' @param ... additional arguments
#'
#' @return  a table which summary the object
#' @export
#'
#' @examples
myfun.data.frame <- function (object, maxsum = 8L, digits = max(3L, getOption("digits")), ...)
{
  ncw <- function(x) {
    z <- nchar(x, type = "w", allowNA = TRUE)
    if (any(na <- is.na(z))) {
      z[na] <- nchar(encodeString(z[na]), "b")
    }
    z
  }
  z <- lapply(X = as.list(object), FUN = myfun, maxsum = maxsum,
              digits = digits, ...)
  nv <- length(object)
  nm <- names(object)
  lw <- numeric(nv)
  nr <- if (nv)
    max(vapply(z, function(x) NROW(x) + !is.null(attr(x,
                                                      "NAs")), integer(1)))
  else 0
  for (i in seq_len(nv)) {
    sms <- z[[i]]
    sms <- format(sms, digits = digits)
    lbs <- format(names(sms))
    sms <- paste0(lbs, ":", sms, "  ")
    lw[i] <- ncw(lbs[1L])
    length(sms) <- nr
    z[[i]] <- sms
  }
  if (nv) {
    z <- unlist(z, use.names = TRUE)
    dim(z) <- c(nr, nv)
    if (anyNA(lw))
      warning("probably wrong encoding in names(.) of column ",
              paste(which(is.na(lw)), collapse = ", "))
    blanks <- paste(character(max(lw, na.rm = TRUE) + 2L),
                    collapse = " ")
    pad <- floor(lw - ncw(nm)/2)
    nm <- paste0(substring(blanks, 1, pad), nm)
    dimnames(z) <- list(rep.int("", nr), nm)
  }
  else {
    z <- character()
    dim(z) <- c(nr, nv)
  }
  attr(z, "class") <- c("table")
  z
}
