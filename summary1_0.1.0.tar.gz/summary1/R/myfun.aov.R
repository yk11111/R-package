#' Title
#'
#' @param object
#' @param intercept
#' @param keep.zero.df
#' @param ...
#'
#' @return
#' @export
#'
#' @examples
myfun.aov <- function (object, intercept = FALSE, keep.zero.df = TRUE, ...)
{
  asgn <- object$assign[object$qr$pivot[1L:object$rank]]
  uasgn <- unique(asgn)
  nterms <- length(uasgn)
  effects <- object$effects
  if (!is.null(effects))
    effects <- as.matrix(effects)[seq_along(asgn), , drop = FALSE]
  rdf <- object$df.residual
  nmeffect <- c("(Intercept)", attr(object$terms, "term.labels"))
  coef <- as.matrix(object$coefficients)
  resid <- as.matrix(object$residuals)
  wt <- object$weights
  if (!is.null(wt))
    resid <- resid * sqrt(wt)
  nresp <- NCOL(resid)
  ans <- vector("list", nresp)
  if (nresp > 1) {
    names(ans) <- character(nresp)
    for (y in 1L:nresp) {
      cn <- colnames(resid)[y]
      if (is.null(cn) || cn == "")
        cn <- y
      names(ans)[y] <- paste(" Response", cn)
    }
  }
  for (y in 1L:nresp) {
    if (is.null(effects)) {
      nterms <- 0L
      df <- ss <- ms <- numeric()
      nmrows <- character()
    }
    else {
      df <- ss <- numeric()
      nmrows <- character()
      for (i in seq(nterms)) {
        ai <- (asgn == uasgn[i])
        df <- c(df, sum(ai))
        ss <- c(ss, sum(effects[ai, y]^2))
        nmi <- nmeffect[1 + uasgn[i]]
        nmrows <- c(nmrows, nmi)
      }
    }
    if (rdf > 0L) {
      df <- c(df, rdf)
      ss <- c(ss, sum(resid[, y]^2))
      nmrows <- c(nmrows, "Residuals")
    }
    nt <- length(df)
    ms <- ifelse(df > 0L, ss/df, NA)
    x <- list(Df = df, `Sum Sq` = ss, `Mean Sq` = ms)
    if (rdf > 0L) {
      TT <- ms/ms[nt]
      TP <- pf(TT, df, rdf, lower.tail = FALSE)
      TT[nt] <- TP[nt] <- NA
      x$"F value" <- TT
      x$"Pr" <- TP
    }
    x <- as.data.frame(x)
    attr(x, "row.names") <- format(nmrows)
    if (!keep.zero.df)
      x <- x[df > 0L, ]
    if (!intercept)
      x <- x[-1, ]
    ans[[y]] <- x
  }
  ans
}
