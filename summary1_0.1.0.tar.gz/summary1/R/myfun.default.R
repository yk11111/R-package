#' Title
#'
#' @param object
#' @param ...
#' @param digits
#' @param quantile.type
#'
#' @return
#' @export
#'
#' @examples
myfun.default <- function (object, ..., digits, quantile.type = 7)
{
  value <- if (is.logical(object))
    c(Mode = "logical", {
      tb <- table(object, exclude = NULL, useNA = "ifany")
      if (!is.null(n <- dimnames(tb)[[1L]]) && any(iN <- is.na(n))) dimnames(tb)[[1L]][iN] <- "NA's"
      tb
    })
  else if (is.recursive(object) && !is.language(object) &&
           (n <- length(object))) {
    sry <- array("", c(n, 3L), list(names(object), c("Length",
                                                       "Class", "Mode")))
    ll <- numeric(n)
    for (i in 1L:n) {
      ii <- object[[i]]
      ll[i] <- length(ii)
      cls <- class(ii)
      sry[i, 2L] <- if (length(cls))
        cls[1L]
      else "-none-"
      sry[i, 3L] <- mode(ii)
    }
    sry[, 1L] <- format(as.integer(ll))
    sry
  }
  else if (is.numeric(object)) {
    nas <- is.na(object)
    object <- object[!nas]
    q1 <- stats::quantile(object, names = FALSE, type = quantile.type)
    q1 <- c(q1[1L:5L],mean(object),sd(object))
    if (!missing(digits))
      q1 <- signif(q1, digits)
    names(q1) <- c("Min.", "1st Qu.", "Median", "3rd Qu.",
                   "Max.", "Mean","SD")
    if (any(nas))
      c(q1, `NA's` = sum(nas))
    else q1
  }
  else c(Length = length(object), Class = class(object), Mode = mode(object))
  value
}
