#' Title
#'
#' @param object
#' @param maxsum
#' @param ...
#'
#' @return
#' @export
#'
#' @examples
myfun.factor <- function (object, maxsum = 50L,...)
{
  nas <- is.na(object)
  ll <- levels(object)
  if (ana <- any(nas))
    maxsum <- maxsum - 1L
  tbl <- table(object)
  tt <- c(tbl)
  names(tt) <- dimnames(tbl)[[1L]]
  if (length(ll) > maxsum) {
    drop <- maxsum:length(ll)
    o <- sort.list(tt, decreasing = TRUE)
    tt <- c(tt[o[-drop]], `(Other)` = sum(tt[o[drop]]))
  }
  if (ana)
    c(tt, `number of NA` = sum(nas))
  else tt
}
