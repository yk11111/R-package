#' Title
#'
#' @param object
#' @param ...
#'
#' @return
#' @export
#'
#' @examples
myfun.matrix <- function (object, ...)
{
  myfun.data.frame(as.data.frame.matrix(object), ...)
}
