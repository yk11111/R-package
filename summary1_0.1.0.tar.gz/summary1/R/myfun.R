#' Title
#'
#' @param x
#' @param ...
#'
#' @return
#' @export
#'
#' @examples
myfun <-function(x,...) {
  UseMethod('myfun')
}
